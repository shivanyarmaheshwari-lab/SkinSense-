from __future__ import annotations

import json
import logging
import math
import re
import sys
from dataclasses import dataclass
from datetime import datetime
from io import BytesIO
from pathlib import Path
from typing import Any, Mapping, Sequence
from zoneinfo import ZoneInfo

import streamlit as st
from PIL import Image, UnidentifiedImageError


logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

st.set_page_config(
    page_title="SkinSense",
    page_icon="🩺",
    layout="centered",
    initial_sidebar_state="collapsed",
)


# -----------------------------------------------------------------------------
# Configuration
# -----------------------------------------------------------------------------

BASE_DIR = Path(__file__).resolve().parent
MODEL_CANDIDATES = (
    BASE_DIR / "skinsense_model.keras",
    BASE_DIR / "model.keras",
    BASE_DIR / "skin_model.keras",
    BASE_DIR / "skinsense_model.h5",
    BASE_DIR / "model.h5",
    BASE_DIR / "saved_model",
)
LABEL_CANDIDATES = (
    BASE_DIR / "class_labels.txt",
    BASE_DIR / "labels.txt",
    BASE_DIR / "class_labels.csv",
    BASE_DIR / "class_indices.json",
)
METADATA_CANDIDATES = (
    BASE_DIR / "model_metadata.json",
    BASE_DIR / "skinsense_model_metadata.json",
)
QUESTION_BANK_CANDIDATES = (
    BASE_DIR / "questions.xlsx",
    BASE_DIR / "question_bank.xlsx",
)

GOOGLE_SCOPES = (
    "https://www.googleapis.com/auth/spreadsheets",
    "https://www.googleapis.com/auth/drive",
)
DEFAULT_WORKSHEET_NAME = "Sheet1"

MAX_NAME_LENGTH = 80
MAX_IMAGE_BYTES = 10 * 1024 * 1024
SUPPORTED_IMAGE_FORMATS = {"JPEG", "PNG"}
SUPPORTED_PYTHON = (3, 12)

VALID_SCREENS = {
    "language",
    "home",
    "upload",
    "questions",
    "result",
    "recovery",
    "chat",
}

URGENCY_HOME = "Manage at home"
URGENCY_DERM = "Visit a dermatologist soon"
URGENCY_URGENT = "Seek immediate medical attention"

URGENT_TERMS = (
    "fever",
    "pus",
    "major swelling",
    "severe pain",
    "rapidly spreading",
    "spreading redness",
    "facial swelling",
    "trouble breathing",
    "bad smell",
    "bleeding",
)


# -----------------------------------------------------------------------------
# Translation dictionaries
# -----------------------------------------------------------------------------

TRANSLATIONS = {
    "English": {
        "continue": "Continue",
        "home": "Home",
        "back": "Back",
        "logout": "Logout",
        "name_title": "Welcome to SkinSense",
        "name_description": "Coastal skin care support for Koli fisherwomen and fishermen.",
        "name_label": "Enter your name",
        "language_title": "Choose your language",
        "home_title": "What would you like to do?",
        "check_skin": "Check my skin",
        "recovery": "Recovery tracking",
        "ask_question": "Ask a skin-care question",
        "upload_title": "Show us the skin problem",
        "upload_help": "Take or upload a clear photo in good light, close to the affected skin.",
        "take_photo": "Take a photo",
        "choose_gallery": "Choose from gallery",
        "questions_title": "A few safety questions",
        "result_title": "Your result",
        "chat_title": "Ask about skin care",
    },
    "हिंदी": {
        "continue": "आगे बढ़ें",
        "home": "होम",
        "back": "पीछे",
        "logout": "लॉग आउट",
        "name_title": "SkinSense में स्वागत है",
        "name_description": "कोली मछुआरा समुदाय के लिए तटीय त्वचा देखभाल सहायता.",
        "name_label": "अपना नाम लिखें",
        "language_title": "भाषा चुनें",
        "home_title": "आप क्या करना चाहेंगे?",
        "check_skin": "त्वचा जांचें",
        "recovery": "रिकवरी ट्रैकिंग",
        "ask_question": "त्वचा देखभाल सवाल पूछें",
        "upload_title": "त्वचा की समस्या दिखाएं",
        "upload_help": "अच्छी रोशनी में प्रभावित त्वचा की साफ नजदीकी फोटो लें या अपलोड करें.",
        "take_photo": "फोटो लें",
        "choose_gallery": "गैलरी से चुनें",
        "questions_title": "कुछ सुरक्षा सवाल",
        "result_title": "आपका परिणाम",
        "chat_title": "त्वचा देखभाल के बारे में पूछें",
    },
    "मराठी": {
        "continue": "पुढे",
        "home": "होम",
        "back": "मागे",
        "logout": "लॉग आउट",
        "name_title": "SkinSense मध्ये स्वागत आहे",
        "name_description": "कोळी मच्छीमार समुदायासाठी किनारी त्वचा काळजी मदत.",
        "name_label": "तुमचे नाव लिहा",
        "language_title": "भाषा निवडा",
        "home_title": "तुम्हाला काय करायचे आहे?",
        "check_skin": "त्वचा तपासा",
        "recovery": "रिकव्हरी ट्रॅकिंग",
        "ask_question": "त्वचा काळजी प्रश्न विचारा",
        "upload_title": "त्वचेची समस्या दाखवा",
        "upload_help": "चांगल्या प्रकाशात प्रभावित त्वचेचा स्पष्ट जवळचा फोटो घ्या किंवा अपलोड करा.",
        "take_photo": "फोटो घ्या",
        "choose_gallery": "गॅलरीतून निवडा",
        "questions_title": "काही सुरक्षा प्रश्न",
        "result_title": "तुमचा निकाल",
        "chat_title": "त्वचा काळजीबद्दल विचारा",
    },
}


# -----------------------------------------------------------------------------
# Data classes
# -----------------------------------------------------------------------------

@dataclass(frozen=True)
class SheetResult:
    saved: bool
    user_message: str = ""


@dataclass(frozen=True)
class ImagePayload:
    data: bytes
    name: str
    image_format: str
    size: tuple[int, int]


@dataclass(frozen=True)
class ModelMetadata:
    model_path: Path
    labels_path: Path
    labels: list[str]
    input_width: int
    input_height: int
    color_mode: str
    rescale: float | None
    output_type: str
    model_format: str


@dataclass(frozen=True)
class PredictionResult:
    model_status: str
    model_version: str
    possible_condition: str | None
    confidence: float | None
    top_conditions: list[tuple[str, float]]
    urgency: str
    next_steps: list[str]
    timestamp: str
    sheet_saved: bool
    sheet_message: str


# -----------------------------------------------------------------------------
# State and styling
# -----------------------------------------------------------------------------

def init_state() -> None:
    defaults = {
        "logged_in": False,
        "user_name": "",
        "language": "English",
        "screen": "language",
        "login_tracking_attempted": False,
        "login_tracking_saved": False,
        "login_tracking_warning": "",
        "login_tracking_warning_shown": False,
        "image_bytes": None,
        "image_name": "",
        "image_format": "",
        "image_size": None,
        "candidate_conditions": [],
        "question_answers": {},
        "result": None,
        "recovery_history": [],
        "chat_history": [],
    }
    for key, value in defaults.items():
        st.session_state.setdefault(key, value)


def t(key: str) -> str:
    language = st.session_state.get("language", "English")
    return TRANSLATIONS.get(language, TRANSLATIONS["English"]).get(key, key)


def apply_branding() -> None:
    st.markdown(
        """
        <style>
        :root {
            --skinsense-bg: #f6fbfd;
            --skinsense-navy: #08213d;
            --skinsense-blue: #076d82;
            --skinsense-muted: #5f7080;
        }
        .stApp { background: var(--skinsense-bg); }
        h1, h2, h3 { color: var(--skinsense-navy); }
        p, li, label { color: var(--skinsense-navy); }
        .skinsense-logo {
            width: 4rem;
            height: 4rem;
            border-radius: 50%;
            background: var(--skinsense-blue);
            color: white;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 2rem;
            margin-bottom: 0.5rem;
        }
        .muted-copy { color: var(--skinsense-muted); line-height: 1.5; }
        .small-note { color: var(--skinsense-muted); font-size: 0.95rem; }
        </style>
        """,
        unsafe_allow_html=True,
    )


# -----------------------------------------------------------------------------
# Validation helpers
# -----------------------------------------------------------------------------

def startup_warnings() -> list[str]:
    warnings: list[str] = []
    if sys.version_info[:2] != SUPPORTED_PYTHON:
        warnings.append(
            f"This app is prepared for Python 3.12. Current runtime is "
            f"Python {sys.version_info.major}.{sys.version_info.minor}."
        )
    if find_existing_path(MODEL_CANDIDATES) is None:
        warnings.append("A trained model file is not present, so image prediction is unavailable.")
    if find_existing_path(LABEL_CANDIDATES) is None:
        warnings.append("A class-label file is not present, so model outputs cannot be mapped safely.")
    return warnings


def clean_name(value: str) -> str:
    cleaned = re.sub(r"[\x00-\x1f\x7f]", "", str(value or ""))
    return re.sub(r"\s+", " ", cleaned).strip()


def current_timestamp() -> str:
    return datetime.now(ZoneInfo("Asia/Kolkata")).isoformat(timespec="seconds")


def find_existing_path(candidates: Sequence[Path]) -> Path | None:
    for candidate in candidates:
        if candidate.exists():
            return candidate
    return None


# -----------------------------------------------------------------------------
# Google Sheets helpers
# -----------------------------------------------------------------------------

def normalize_private_key(value: Any) -> str:
    key = str(value or "").strip()
    key = key.replace("\\n", "\n").replace("\r\n", "\n").replace("\r", "\n")

    begin_marker = "-----BEGIN PRIVATE KEY-----"
    end_marker = "-----END PRIVATE KEY-----"
    if begin_marker not in key or end_marker not in key:
        raise ValueError("The Google service-account private key is malformed or incomplete.")

    start = key.index(begin_marker)
    end = key.index(end_marker) + len(end_marker)
    key = key[start:end]
    lines = [line.strip() for line in key.split("\n") if line.strip()]
    normalized = "\n".join(lines) + "\n"
    if not normalized.startswith(begin_marker) or not normalized.rstrip().endswith(end_marker):
        raise ValueError("The Google service-account private key is malformed or incomplete.")
    return normalized


def service_account_from_secrets(secrets: Mapping[str, Any]) -> dict[str, Any]:
    for section_name in ("gcp_service_account", "google_service_account", "service_account"):
        if section_name in secrets:
            info = dict(secrets[section_name])
            break
    else:
        raise KeyError("No supported Google service-account section is configured.")

    required = (
        "type",
        "project_id",
        "private_key_id",
        "private_key",
        "client_email",
        "client_id",
        "auth_uri",
        "token_uri",
        "auth_provider_x509_cert_url",
        "client_x509_cert_url",
    )
    missing = [field for field in required if not info.get(field)]
    if missing:
        raise ValueError("Missing required Google service-account fields.")
    info["private_key"] = normalize_private_key(info["private_key"])
    return info


def sheet_config_from_secrets(secrets: Mapping[str, Any]) -> tuple[str, str]:
    if "google_sheets" in secrets:
        sheet_config = dict(secrets["google_sheets"])
        sheet_id = str(sheet_config.get("spreadsheet_id", "")).strip()
        worksheet_name = str(sheet_config.get("worksheet_name", DEFAULT_WORKSHEET_NAME)).strip()
    else:
        sheet_id = str(secrets.get("google_sheet_id", "")).strip()
        worksheet_name = str(secrets.get("worksheet_name", DEFAULT_WORKSHEET_NAME)).strip()

    if not sheet_id:
        raise ValueError("Missing Google Sheets spreadsheet ID.")
    return sheet_id, worksheet_name or DEFAULT_WORKSHEET_NAME


@st.cache_resource(show_spinner=False)
def get_google_sheets_client(credentials_info: dict[str, Any]):
    import gspread
    from google.oauth2.service_account import Credentials

    credentials = Credentials.from_service_account_info(credentials_info, scopes=list(GOOGLE_SCOPES))
    return gspread.authorize(credentials)


def get_worksheet():
    credentials_info = service_account_from_secrets(st.secrets)
    sheet_id, worksheet_name = sheet_config_from_secrets(st.secrets)
    client = get_google_sheets_client(credentials_info)
    spreadsheet = client.open_by_key(sheet_id)
    return spreadsheet.worksheet(worksheet_name)


def append_row_to_sheet(row: list[Any]) -> SheetResult:
    try:
        worksheet = get_worksheet()
        worksheet.append_row(row, value_input_option="RAW")
        return SheetResult(saved=True)
    except Exception:
        logger.exception("Google Sheets operation failed")
        return SheetResult(
            saved=False,
            user_message="SkinSense opened successfully, but usage tracking could not be saved.",
        )


def append_login_record(cleaned_name: str) -> SheetResult:
    return append_row_to_sheet([current_timestamp(), cleaned_name])


def append_prediction_record(result: PredictionResult) -> SheetResult:
    row = [
        result.timestamp,
        st.session_state.get("user_name", ""),
        result.possible_condition or "",
        "" if result.confidence is None else round(result.confidence, 4),
        result.urgency,
        result.model_status,
    ]
    saved = append_row_to_sheet(row)
    if not saved.saved:
        return SheetResult(saved=False, user_message="The screening result was shown, but it could not be saved.")
    return saved


def enter_app_with_name(name: str) -> tuple[bool, str]:
    cleaned_name = clean_name(name)
    if not cleaned_name:
        return False, "Please enter your name to continue."
    if len(cleaned_name) > MAX_NAME_LENGTH:
        return False, "Please enter a shorter name, up to 80 characters."

    st.session_state["logged_in"] = True
    st.session_state["user_name"] = cleaned_name
    st.session_state["screen"] = "language"

    if not st.session_state.get("login_tracking_attempted"):
        st.session_state["login_tracking_attempted"] = True
        tracking = append_login_record(cleaned_name)
        st.session_state["login_tracking_saved"] = tracking.saved
        if not tracking.saved:
            st.session_state["login_tracking_warning"] = tracking.user_message
    return True, "Welcome to SkinSense."


# -----------------------------------------------------------------------------
# Image validation
# -----------------------------------------------------------------------------

def validate_image(uploaded_file: Any) -> tuple[bool, str, ImagePayload | None]:
    if uploaded_file is None:
        return False, "Please take or upload a photo first.", None

    raw = uploaded_file.getvalue()
    if not raw:
        return False, "The selected image is empty. Please try another photo.", None
    if len(raw) > MAX_IMAGE_BYTES:
        return False, "Please use an image under 10 MB.", None

    try:
        probe = Image.open(BytesIO(raw))
        image_format = (probe.format or "").upper()
        probe.verify()
        image = Image.open(BytesIO(raw))
    except (UnidentifiedImageError, OSError, ValueError):
        return False, "This file could not be read as an image. Please use JPG or PNG.", None

    if image_format not in SUPPORTED_IMAGE_FORMATS:
        return False, "Please use a JPG, JPEG, or PNG image.", None

    width, height = image.size
    if width <= 0 or height <= 0:
        return False, "This image has invalid dimensions. Please try another photo.", None

    return True, "Image ready.", ImagePayload(
        data=raw,
        name=getattr(uploaded_file, "name", "camera_photo.jpg"),
        image_format=image_format,
        size=(width, height),
    )


# -----------------------------------------------------------------------------
# Model loading and prediction
# -----------------------------------------------------------------------------

def model_format_from_path(path: Path) -> str:
    if path.is_dir():
        if (path / "saved_model.pb").exists():
            return "TensorFlow SavedModel directory"
        return "model directory"
    suffix = path.suffix.lower()
    if suffix == ".keras":
        return "Keras v3 .keras"
    if suffix == ".h5":
        return "Keras HDF5 .h5"
    if suffix == ".tflite":
        return "TensorFlow Lite .tflite"
    return suffix or "unknown"


def load_labels(labels_path: Path) -> list[str]:
    suffix = labels_path.suffix.lower()
    if suffix == ".json":
        payload = json.loads(labels_path.read_text(encoding="utf-8"))
        if isinstance(payload, dict):
            if all(isinstance(value, int) for value in payload.values()):
                return [label for label, _index in sorted(payload.items(), key=lambda item: item[1])]
            if "labels" in payload and isinstance(payload["labels"], list):
                return [str(label).strip() for label in payload["labels"] if str(label).strip()]
        raise ValueError("Label JSON must be class_indices or contain a labels list.")
    if suffix == ".csv":
        import pandas as pd

        data = pd.read_csv(labels_path)
        column = "label" if "label" in data.columns else data.columns[0]
        return [str(value).strip() for value in data[column].tolist() if str(value).strip()]
    return [line.strip() for line in labels_path.read_text(encoding="utf-8").splitlines() if line.strip()]


def read_model_json_metadata(path: Path | None) -> dict[str, Any]:
    if path is None:
        return {}
    return json.loads(path.read_text(encoding="utf-8"))


def infer_model_dimensions(model: Any) -> tuple[int, int, int]:
    input_shape = getattr(model, "input_shape", None)
    if isinstance(input_shape, list):
        input_shape = input_shape[0]
    if not input_shape or len(input_shape) < 4:
        raise ValueError("The model input shape could not be read.")

    height = input_shape[1]
    width = input_shape[2]
    channels = input_shape[3]
    if height is None or width is None or channels is None:
        raise ValueError("The model must have fixed image height, width, and channels.")
    return int(width), int(height), int(channels)


def infer_output_classes(model: Any) -> int:
    output_shape = getattr(model, "output_shape", None)
    if isinstance(output_shape, list):
        output_shape = output_shape[0]
    if not output_shape or len(output_shape) < 2 or output_shape[-1] is None:
        raise ValueError("The model output class count could not be read.")
    return int(output_shape[-1])


@st.cache_resource(show_spinner=False)
def load_skin_model() -> tuple[Any | None, ModelMetadata | None, str | None]:
    model_path = find_existing_path(MODEL_CANDIDATES)
    labels_path = find_existing_path(LABEL_CANDIDATES)
    metadata_path = find_existing_path(METADATA_CANDIDATES)

    if model_path is None:
        return None, None, "No trained model file is present in the Streamlit app folder."
    if labels_path is None:
        return None, None, "No class-label file is present. Add labels in the exact training order."
    if metadata_path is None:
        return None, None, (
            "Model metadata is missing. Add model_metadata.json with the training preprocessing "
            "before running predictions."
        )

    if model_path.suffix.lower() == ".tflite":
        return None, None, "A TFLite model was found, but this app currently supports Keras/SavedModel files."

    try:
        import tensorflow as tf

        model = tf.keras.models.load_model(model_path)
        labels = load_labels(labels_path)
        metadata_json = read_model_json_metadata(metadata_path)
        inferred_width, inferred_height, channels = infer_model_dimensions(model)
        class_count = infer_output_classes(model)
    except Exception as exc:
        logger.exception("SkinSense model loading failed")
        return None, None, f"The trained model could not be loaded: {exc}"

    if channels not in (1, 3):
        return None, None, f"The model expects {channels} image channels, which this app does not support."
    if len(labels) != class_count:
        return None, None, (
            f"Model outputs {class_count} classes, but {len(labels)} class labels were found. "
            "Keep labels in the exact training order."
        )

    color_mode = str(metadata_json.get("color_mode", "RGB" if channels == 3 else "L")).upper()
    if color_mode not in ("RGB", "L"):
        return None, None, "model_metadata.json color_mode must be RGB or L."
    rescale = metadata_json.get("rescale")
    if rescale is None:
        return None, None, "model_metadata.json must include the training pixel rescale value."

    width = int(metadata_json.get("input_width", inferred_width))
    height = int(metadata_json.get("input_height", inferred_height))
    if width != inferred_width or height != inferred_height:
        return None, None, "Metadata input size does not match the saved model input shape."

    metadata = ModelMetadata(
        model_path=model_path,
        labels_path=labels_path,
        labels=labels,
        input_width=width,
        input_height=height,
        color_mode=color_mode,
        rescale=float(rescale),
        output_type=str(metadata_json.get("output_type", "auto")).lower(),
        model_format=model_format_from_path(model_path),
    )
    return model, metadata, None


def softmax(values: Sequence[float]) -> list[float]:
    maximum = max(values)
    exponents = [math.exp(value - maximum) for value in values]
    total = sum(exponents)
    return [value / total for value in exponents]


def output_to_probabilities(raw_values: Sequence[float], output_type: str) -> list[float]:
    values = [float(value) for value in raw_values]
    if output_type == "logits":
        return softmax(values)
    if output_type == "probabilities":
        total = sum(values)
        if total <= 0:
            raise ValueError("Model probability output is invalid.")
        return [max(value, 0.0) / total for value in values]

    looks_like_probabilities = all(0.0 <= value <= 1.0 for value in values) and abs(sum(values) - 1.0) <= 0.05
    if looks_like_probabilities:
        total = sum(values)
        return [value / total for value in values]
    return softmax(values)


def preprocess_image_for_model(image_bytes: bytes, metadata: ModelMetadata) -> Any:
    import numpy as np

    image = Image.open(BytesIO(image_bytes)).convert(metadata.color_mode)
    image = image.resize((metadata.input_width, metadata.input_height), Image.Resampling.BILINEAR)
    array = np.asarray(image, dtype="float32")
    if metadata.color_mode == "L":
        array = array[..., np.newaxis]
    if metadata.rescale is not None:
        array = array * metadata.rescale
    return np.expand_dims(array, axis=0)


def run_image_inference(image_bytes: bytes) -> tuple[dict[str, Any] | None, str | None]:
    model, metadata, error = load_skin_model()
    if error or model is None or metadata is None:
        return None, error

    try:
        batch = preprocess_image_for_model(image_bytes, metadata)
        prediction = model.predict(batch, verbose=0)
        raw_values = prediction[0].tolist()
        probabilities = output_to_probabilities(raw_values, metadata.output_type)
        ranked = sorted(enumerate(probabilities), key=lambda item: item[1], reverse=True)
        top_conditions = [(metadata.labels[index], float(probability)) for index, probability in ranked[:3]]
        best_label, confidence = top_conditions[0]
        return {
            "status": f"Real model loaded from {metadata.model_path.name} ({metadata.model_format}).",
            "model_version": metadata.model_path.name,
            "possible_condition": best_label,
            "confidence": confidence,
            "top_conditions": top_conditions,
        }, None
    except Exception as exc:
        logger.exception("SkinSense model prediction failed")
        return None, f"The trained model could not complete prediction: {exc}"


# -----------------------------------------------------------------------------
# Question bank and result logic
# -----------------------------------------------------------------------------

def read_question_bank() -> dict[str, list[str]]:
    path = find_existing_path(QUESTION_BANK_CANDIDATES)
    if path is None:
        return {}

    try:
        import pandas as pd

        data = pd.read_excel(path)
        disease_col = "disease" if "disease" in data.columns else data.columns[0]
        question_col = "question" if "question" in data.columns else data.columns[1]
        questions: dict[str, list[str]] = {}
        for _index, row in data.iterrows():
            disease = str(row[disease_col]).strip()
            question = str(row[question_col]).strip()
            if disease and question and question.lower() != "nan":
                questions.setdefault(disease, []).append(question)
        return questions
    except Exception:
        logger.exception("Question bank could not be read")
        return {}


def followup_questions(top_conditions: list[tuple[str, float]]) -> list[str]:
    if not top_conditions:
        return [
            "Do you have fever, pus, major swelling, severe pain, or rapidly spreading redness?",
            "Do you have facial swelling or trouble breathing?",
        ]

    bank = read_question_bank()
    collected: list[str] = []
    for label, _probability in top_conditions:
        collected.extend(bank.get(label, []))

    if collected:
        return collected[:2]
    return [
        "Do you have fever, pus, major swelling, severe pain, or rapidly spreading redness?",
        "Do you have facial swelling or trouble breathing?",
    ]


def urgency_from_answers(answers: Mapping[str, str]) -> tuple[str, list[str]]:
    yes_answers = [answer for answer in answers.values() if answer == "Yes"]
    if yes_answers:
        return URGENCY_URGENT, [
            "Please seek medical care urgently for severe or fast-worsening symptoms.",
            "Keep the area clean and avoid scratching or applying unknown creams.",
        ]
    return URGENCY_DERM, [
        "Keep the area clean and dry after seawater exposure.",
        "Visit a dermatologist soon if it spreads, hurts, forms pus, or does not improve.",
    ]


def build_result(inference: dict[str, Any], answers: Mapping[str, str]) -> PredictionResult:
    urgency, next_steps = urgency_from_answers(answers)
    result = PredictionResult(
        model_status=inference["status"],
        model_version=inference["model_version"],
        possible_condition=inference["possible_condition"],
        confidence=inference["confidence"],
        top_conditions=inference["top_conditions"],
        urgency=urgency,
        next_steps=next_steps,
        timestamp=current_timestamp(),
        sheet_saved=False,
        sheet_message="",
    )
    sheet_result = append_prediction_record(result)
    return PredictionResult(
        model_status=result.model_status,
        model_version=result.model_version,
        possible_condition=result.possible_condition,
        confidence=result.confidence,
        top_conditions=result.top_conditions,
        urgency=result.urgency,
        next_steps=result.next_steps,
        timestamp=result.timestamp,
        sheet_saved=sheet_result.saved,
        sheet_message=sheet_result.user_message,
    )


# -----------------------------------------------------------------------------
# Navigation
# -----------------------------------------------------------------------------

def navigate(screen: str) -> None:
    if screen not in VALID_SCREENS:
        logger.warning("Invalid screen requested: %s", screen)
        st.session_state["screen"] = "language"
    else:
        st.session_state["screen"] = screen
    st.rerun()


def logout() -> None:
    st.session_state.clear()
    st.rerun()


def top_navigation(show_back: bool = False, back_to: str = "home") -> None:
    columns = st.columns([1, 1, 1])
    with columns[0]:
        if show_back and st.button(t("back"), use_container_width=True):
            navigate(back_to)
    with columns[1]:
        if st.button(t("home"), use_container_width=True):
            navigate("home")
    with columns[2]:
        if st.button(t("logout"), use_container_width=True):
            logout()


def show_tracking_warning_once() -> None:
    warning = st.session_state.get("login_tracking_warning")
    if warning and not st.session_state.get("login_tracking_warning_shown"):
        st.warning(warning)
        st.session_state["login_tracking_warning_shown"] = True


# -----------------------------------------------------------------------------
# Pages
# -----------------------------------------------------------------------------

def name_entry_page() -> None:
    st.markdown('<div class="skinsense-logo">🩺</div>', unsafe_allow_html=True)
    st.title(t("name_title"))
    st.write(t("name_description"))

    with st.container(border=True):
        with st.form("name_form", clear_on_submit=False):
            name = st.text_input(t("name_label"), max_chars=MAX_NAME_LENGTH)
            submitted = st.form_submit_button(t("continue"), use_container_width=True)

        if submitted:
            success, message = enter_app_with_name(name)
            if success:
                st.success(message)
                st.rerun()
            st.warning(message)

    st.caption("SkinSense is an AI screening aid, not a medical diagnosis. For serious symptoms, please see a doctor.")


def language_page() -> None:
    top_navigation()
    st.title(t("language_title"))
    st.caption(f"Name: {st.session_state.get('user_name', '')}")
    language = st.radio(
        "Language",
        ["English", "हिंदी", "मराठी"],
        index=["English", "हिंदी", "मराठी"].index(st.session_state.get("language", "English")),
        horizontal=True,
    )
    st.session_state["language"] = language
    if st.button(t("continue"), use_container_width=True):
        navigate("home")


def home_page() -> None:
    top_navigation()
    st.title(t("home_title"))
    warnings = startup_warnings()
    if warnings:
        with st.expander("App setup status", expanded=False):
            for warning in warnings:
                st.warning(warning)

    if st.button(t("check_skin"), use_container_width=True):
        navigate("upload")
    if st.button(t("recovery"), use_container_width=True):
        navigate("recovery")
    if st.button(t("ask_question"), use_container_width=True):
        navigate("chat")


def upload_page() -> None:
    top_navigation(show_back=True, back_to="home")
    st.title(t("upload_title"))
    st.write(t("upload_help"))

    camera_image = st.camera_input(t("take_photo"))
    gallery_image = st.file_uploader(t("choose_gallery"), type=["jpg", "jpeg", "png"])
    selected_file = camera_image or gallery_image

    if selected_file:
        valid, message, payload = validate_image(selected_file)
        if valid and payload:
            st.session_state["image_bytes"] = payload.data
            st.session_state["image_name"] = payload.name
            st.session_state["image_format"] = payload.image_format
            st.session_state["image_size"] = payload.size
            st.image(payload.data, caption=f"{payload.image_format} • {payload.size[0]} x {payload.size[1]}")
        else:
            st.warning(message)

    if st.session_state.get("image_bytes") and st.button(t("continue"), use_container_width=True):
        with st.spinner("Running image screening..."):
            inference, error = run_image_inference(st.session_state["image_bytes"])
        if error or inference is None:
            st.error(error)
            st.info("Add the trained model, exact class labels, and model metadata before using AI prediction.")
            return
        st.session_state["candidate_conditions"] = inference["top_conditions"]
        st.session_state["inference"] = inference
        navigate("questions")


def questions_page() -> None:
    top_navigation(show_back=True, back_to="upload")
    inference = st.session_state.get("inference")
    if not inference:
        st.warning("Please upload a valid image first.")
        return

    questions = followup_questions(inference["top_conditions"])
    st.title(t("questions_title"))
    st.write("Answer these Yes/No questions before viewing the result.")

    with st.form("followup_form"):
        answers: dict[str, str] = {}
        for index, question in enumerate(questions, start=1):
            answers[question] = st.radio(
                f"Q{index}. {question}",
                ["Yes", "No"],
                horizontal=True,
                index=None,
            )
        submitted = st.form_submit_button("See result", use_container_width=True)

    if submitted:
        if any(answer is None for answer in answers.values()):
            st.warning("Please answer every question before continuing.")
            return
        st.session_state["question_answers"] = answers
        result = build_result(inference, answers)
        st.session_state["result"] = result
        st.session_state["recovery_history"].append(
            {
                "timestamp": result.timestamp,
                "image_bytes": st.session_state.get("image_bytes"),
                "summary": result.possible_condition or "No condition available",
                "urgency": result.urgency,
                "status": "Not compared",
            }
        )
        navigate("result")


def result_page() -> None:
    top_navigation(show_back=True, back_to="questions")
    result: PredictionResult | None = st.session_state.get("result")
    if not result:
        st.warning("No result yet. Please complete a skin check first.")
        return

    st.title(t("result_title"))
    image_bytes = st.session_state.get("image_bytes")
    if image_bytes:
        st.image(image_bytes, caption="Uploaded image", use_container_width=True)

    with st.container(border=True):
        st.subheader("AI screening estimate")
        st.write(result.model_status)
        st.markdown(f"**Possible condition:** {result.possible_condition}")
        st.write(f"Confidence: {round((result.confidence or 0) * 100)}%")
        st.caption("Top model outputs:")
        for label, probability in result.top_conditions:
            st.write(f"{label}: {round(probability * 100)}%")

    if result.urgency == URGENCY_URGENT:
        st.error(result.urgency)
    elif result.urgency == URGENCY_DERM:
        st.warning(result.urgency)
    else:
        st.success(result.urgency)

    with st.container(border=True):
        st.subheader("Next steps")
        for step in result.next_steps:
            st.write(f"- {step}")

    if result.sheet_saved:
        st.success("Result saved.")
    elif result.sheet_message:
        st.warning(result.sheet_message)

    st.info("This is an AI screening estimate, not a medical diagnosis. Please see a dermatologist for serious or worsening symptoms.")


def recovery_page() -> None:
    top_navigation(show_back=True, back_to="home")
    st.title(t("recovery"))
    history = st.session_state.get("recovery_history", [])
    if not history:
        st.info("No skin checks in this session yet.")
        return

    for index, item in enumerate(reversed(history), start=1):
        with st.container(border=True):
            st.subheader(f"Check {index}")
            st.write(item["timestamp"])
            if item.get("image_bytes"):
                st.image(item["image_bytes"], width=260)
            st.write(f"Summary: {item['summary']}")
            st.write(f"Urgency: {item['urgency']}")
            status = st.radio(
                "How does it look now?",
                ["Improving", "Unchanged", "Worsening"],
                horizontal=True,
                key=f"recovery_status_{index}",
                index=None,
            )
            if status:
                item["status"] = status
    st.caption("SkinSense stores this recovery history only during the current session.")


def urgent_chat_needed(message: str) -> bool:
    lowered = message.lower()
    return any(term in lowered for term in URGENT_TERMS)


def answer_chat(message: str) -> str:
    if urgent_chat_needed(message):
        return (
            "Please seek urgent medical care for fever, pus, major swelling, severe pain, rapidly spreading redness, "
            "facial swelling, or trouble breathing."
        )
    lowered = message.lower()
    if "salt" in lowered or "sea" in lowered or "water" in lowered:
        return "After seawater work, rinse with clean water, dry well, change wet gloves or boots, and cover small cuts."
    if "itch" in lowered:
        return "Do not scratch. Wash gently, dry the skin, and avoid staying in wet gloves or boots for long periods."
    if "sun" in lowered:
        return "Cover exposed skin, rest in shade when possible, drink water, and seek care for blisters or severe pain."
    return "I can share general skin-care guidance, but I cannot diagnose through chat. Please see a dermatologist if it worsens."


def chat_page() -> None:
    top_navigation(show_back=True, back_to="home")
    st.title(t("chat_title"))
    st.write("This helper gives general guidance only and does not diagnose.")

    for role, message in st.session_state["chat_history"]:
        with st.chat_message(role):
            st.write(message)

    prompt = st.chat_input("Type your question...")
    if prompt is not None:
        cleaned = prompt.strip()
        if cleaned:
            st.session_state["chat_history"].append(("user", cleaned))
            st.session_state["chat_history"].append(("assistant", answer_chat(cleaned)))
            st.rerun()
        st.warning("Please type a question.")

    columns = st.columns(2)
    with columns[0]:
        if st.button("Clear chat", use_container_width=True):
            st.session_state["chat_history"] = []
            st.rerun()
    with columns[1]:
        if st.button(t("home"), use_container_width=True):
            navigate("home")


# -----------------------------------------------------------------------------
# Main router
# -----------------------------------------------------------------------------

def main() -> None:
    init_state()
    apply_branding()

    if not st.session_state.get("logged_in"):
        name_entry_page()
        return

    show_tracking_warning_once()

    screen = st.session_state.get("screen", "language")
    if screen not in VALID_SCREENS:
        st.session_state["screen"] = "language"
        st.rerun()

    if screen == "language":
        language_page()
    elif screen == "home":
        home_page()
    elif screen == "upload":
        upload_page()
    elif screen == "questions":
        questions_page()
    elif screen == "result":
        result_page()
    elif screen == "recovery":
        recovery_page()
    elif screen == "chat":
        chat_page()


if __name__ == "__main__":
    main()
