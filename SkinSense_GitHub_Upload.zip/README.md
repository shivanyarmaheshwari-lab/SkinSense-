# SkinSense Streamlit App

SkinSense is a Streamlit healthcare screening app for Koli fisherwomen and fishermen. It includes name entry, language selection, image upload, TensorFlow model inference when trained model files are present, recovery tracking, basic skin-care chat, and Google Sheets logging.

This app is an AI screening aid, not a medical diagnosis.

## Python Version

Streamlit Community Cloud Python version: 3.12

The repository includes `.python-version` with `3.12`, but Streamlit Community Cloud may keep an already-created deployment on its existing runtime. Select Python 3.12 in the app's Advanced settings when deploying.

If the current Streamlit app is already locked to Python 3.14.6, delete the failed deployment and recreate it with Python 3.12 selected.

## Files

- `app.py`: Streamlit Cloud entry point and full app code.
- `requirements.txt`: Python 3.12 dependency pins.
- `.python-version`: Local/runtime Python hint.
- `.gitignore`: Excludes local secrets, service-account files, virtual environments, and cache files.

## Dependencies

```text
streamlit==1.41.1
gspread==6.1.4
google-auth==2.37.0
Pillow==11.0.0
pandas==2.2.3
openpyxl==3.1.5
tensorflow==2.18.0
numpy==2.0.2
```

## Local Setup

```bash
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
streamlit run app.py
```

## Google Sheets Setup

1. Create a Google Cloud service account.
2. Enable the Google Sheets API.
3. Enable the Google Drive API.
4. Create a service-account key.
5. Copy the service-account values into Streamlit Secrets.
6. Share the Google Sheet with the service account `client_email`.
7. Make sure the worksheet name exists.

Use this secrets format:

```toml
[gcp_service_account]
type = "service_account"
project_id = "PROJECT_ID"
private_key_id = "PRIVATE_KEY_ID"
private_key = """-----BEGIN PRIVATE KEY-----
COMPLETE_UNEDITED_PRIVATE_KEY
-----END PRIVATE KEY-----
"""
client_email = "SERVICE_ACCOUNT_EMAIL"
client_id = "CLIENT_ID"
auth_uri = "https://accounts.google.com/o/oauth2/auth"
token_uri = "https://oauth2.googleapis.com/token"
auth_provider_x509_cert_url = "https://www.googleapis.com/oauth2/v1/certs"
client_x509_cert_url = "CERTIFICATE_URL"
universe_domain = "googleapis.com"

[google_sheets]
spreadsheet_id = "SPREADSHEET_ID"
worksheet_name = "Sheet1"
```

The app also supports legacy top-level `google_sheet_id` and `worksheet_name`, but the `[google_sheets]` section is preferred.

Google Sheets logging does not block the user from entering the app. If Sheets fails, the app shows a friendly warning and logs the technical exception without exposing secrets.

## Model Files

Place the trained TensorFlow/Keras model in the Streamlit app folder using one of these names:

```text
skinsense_model.keras
model.keras
skin_model.keras
skinsense_model.h5
model.h5
saved_model/
```

Place class labels in the exact training order using one of these files:

```text
class_labels.txt
labels.txt
class_labels.csv
class_indices.json
```

Add model preprocessing metadata:

```json
{
  "input_width": 224,
  "input_height": 224,
  "color_mode": "RGB",
  "rescale": 0.00392156862745098,
  "output_type": "auto"
}
```

Save that as:

```text
model_metadata.json
```

Do not guess class-label order. Use the same class order from training, such as Keras `class_indices`.

If the model file is too large for normal Git, use Git LFS and confirm Streamlit Cloud pulls the LFS file during deployment.

## Optional Question Bank

If you want disease-specific follow-up questions, add:

```text
questions.xlsx
```

It should contain columns named:

```text
disease
question
```

Only the first two Yes/No questions are shown.

## Deployment to Streamlit Community Cloud

1. Push the corrected repository to GitHub.
2. In Streamlit Community Cloud, select `app.py` as the main file.
3. Open Advanced settings.
4. Select Python 3.12.
5. Paste Streamlit Secrets.
6. Deploy.
7. Confirm the build log says Python 3.12, not Python 3.14.
8. Test name entry and Google Sheets logging.
9. Upload a valid image and confirm the real model prediction completes.

Important: if the current Streamlit application is already running Python 3.14.6, repository changes alone will not change that existing runtime. Copy the current Streamlit Secrets, delete the existing failed Streamlit deployment, create the app again from the same GitHub repository, select Python 3.12 in Advanced settings, paste the Secrets again, deploy, and confirm the build log says Python 3.12.

## Checks

Run these before deploying:

```bash
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m pip check
python -m compileall .
python -c "import streamlit, gspread, google.auth, PIL, pandas, tensorflow; print('imports ok')"
streamlit run app.py --server.headless true --server.port 8501
```

Where real credentials are unavailable, the app should start and show a clear configuration message rather than crash.
